package com.example.easyreadv2_baybay

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
